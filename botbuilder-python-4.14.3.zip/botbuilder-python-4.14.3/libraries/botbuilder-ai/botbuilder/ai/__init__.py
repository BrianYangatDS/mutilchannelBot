# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .about import __title__, __version__

__all__ = ["__title__", "__version__"]
